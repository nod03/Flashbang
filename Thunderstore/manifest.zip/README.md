Within a radius of 80, enemies are damaged and stunned for 5 seconds and players are flashbanged.
Deals 50 or 10% of maximum enemy health, whichever is larger.
Cooldown 25 seconds.